# Mã nguồn SCROLL SMART

Trang: https://scroll-smart-nhat-ky-son.truongson27012010.chatgpt.site/
Mã nguồn tải ngày 08/11/2026, commit 42d7d05b649db2504ec2cfb00e5bb91ed9317f23.

## Nội dung
- app/: giao diện nhật kí, quản trị và các API.
- lib/: thống kê, phân nhóm 5 phút cuối, xuất ảnh biểu đồ và danh sách mã.
- db/, drizzle/: cấu trúc và migration cơ sở dữ liệu.
- worker/, scripts/: phần máy chủ Cloudflare Worker và công cụ chạy/build.
- package.json, pnpm-lock.yaml: thư viện và phiên bản phụ thuộc.

## Chạy trên máy
1. Cài Node.js >=22.13.0 và pnpm theo phiên bản packageManager trong package.json.
2. Giải nén, mở terminal trong thư mục dự án.
3. Chạy pnpm install --frozen-lockfile.
4. Chạy pnpm run build để tạo cấu hình Worker.
5. Áp dụng từng migration SQL trong drizzle/ theo thứ tự, sử dụng lệnh D1 cục bộ trong README.md.
6. Chạy pnpm run dev; mở địa chỉ được in ra terminal.

Bản xuất này chứa mã nguồn; không xuất dữ liệu nhật kí đang lưu trên web, phiên đăng nhập hay biến bí mật ở môi trường máy chủ. Khi chạy cục bộ cần khởi tạo cơ sở dữ liệu riêng. Không phải một tệp HTML có thể mở trực tiếp bằng cách bấm đúp.

## Triển khai
Ứng dụng hiện dùng Vinext, Cloudflare Worker và Cloudflare D1 (binding DB). Nếu muốn đưa lên GitHub, có thể tải các tệp này vào kho riêng. Đưa lên Vercel cần chuyển đổi phần máy chủ/cơ sở dữ liệu và cơ chế đăng nhập phù hợp; tải nguyên thư mục lên Vercel không bảo đảm chạy được. README.md giữ lại hướng dẫn kỹ thuật gốc.

Không có thay đổi hoặc triển khai nào lên trang đang chạy trong thao tác xuất mã nguồn này. Các tệp nguồn được giữ nguyên; chỉ thêm tệp hướng dẫn này.
