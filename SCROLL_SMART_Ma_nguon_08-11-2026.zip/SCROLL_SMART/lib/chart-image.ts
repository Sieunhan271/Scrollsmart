export type ChartImageSeries={name:string;color:string;values:(number|null)[];pointColors?:string[]};
export type ChartImageOptions={title:string;subtitle:string;unit:string;labels:string[];series:ChartImageSeries[];kind:'line'|'bar';integerAxis?:boolean;note?:string};
const esc=(v:string)=>v.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&apos;');
const format=(n:number)=>n.toLocaleString('vi-VN',{maximumFractionDigits:2});
export function buildChartSvg(o:ChartImageOptions){
 const width=1280,left=100,right=55,top=190,bottom=600,pw=width-left-right,ph=bottom-top;
 const legendItems:{x:number;row:number;series:ChartImageSeries}[]=[];let lx=left,lr=0;
 o.series.forEach(series=>{const itemWidth=Math.max(210,series.name.length*9+70);if(lx+itemWidth>width-right&&lx>left){lr++;lx=left}legendItems.push({x:lx,row:lr,series});lx+=itemWidth});
 const height=760+lr*34;
 const hasValue=(v:number|null|undefined):v is number=>typeof v==='number'&&Number.isFinite(v);
 const values=o.series.flatMap(s=>s.values).filter(hasValue),max=Math.max(0,...values);
 const rawStep=max/4||1,power=10**Math.floor(Math.log10(rawStep)),fraction=rawStep/power;
 let step=([1,2,2.5,5,10].find(n=>n>=fraction)??10)*power;if(o.integerAxis)step=Math.max(1,Math.ceil(step));const ymax=step*4;
 const x=(i:number)=>o.kind==='bar'?left+pw*(i+.5)/Math.max(o.labels.length,1):left+pw*(o.labels.length>1?i/(o.labels.length-1):.5);
 const y=(v:number)=>bottom-ph*v/ymax;
 const text=(x:number,y:number,value:string,size=16,fill='#74816e',extra='')=>`<text x="${x}" y="${y}" fill="${fill}" font-size="${size}" ${extra}>${esc(value)}</text>`;
 let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="${width}" height="${height}" fill="#ffffff"/><g font-family="Arial, Helvetica, sans-serif">`;
 svg+=text(64,48,'SCROLL SMART',16,'#47775e','font-weight="700" letter-spacing="2"');
 svg+=text(64,94,o.title,30,'#243d33','font-weight="700"');svg+=text(64,128,o.subtitle,18);svg+=text(left,170,o.unit,16);
 for(let i=0;i<=4;i++){const value=step*i,py=y(value);svg+=`<line x1="${left}" x2="${width-right}" y1="${py}" y2="${py}" stroke="#e4eae0" stroke-dasharray="5 6"/>`;svg+=text(left-20,py+6,format(value),16,'#74816e','text-anchor="end"');}
 o.labels.forEach((label,i)=>{svg+=text(x(i),bottom+35,label,16,'#74816e','text-anchor="middle"')});
 o.series.forEach(s=>{
  if(o.kind==='line'){
   let segment='';const paths:string[]=[];
   o.labels.forEach((_,i)=>{const v=s.values[i];if(!hasValue(v)){if(segment)paths.push(segment);segment='';return;}segment+=(segment?' L':'M')+x(i)+' '+y(v)});if(segment)paths.push(segment);
   paths.forEach(d=>svg+=`<path d="${d}" stroke="${esc(s.color)}" fill="none" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>`);
   o.labels.forEach((_,i)=>{const v=s.values[i];if(hasValue(v))svg+=`<circle cx="${x(i)}" cy="${y(v)}" r="5" fill="#fff" stroke="${esc(s.color)}" stroke-width="3"/>`});
  }else{
   const group=Math.min(pw/Math.max(o.labels.length,1)*.65,100),bw=group/Math.max(o.series.length,1);
   const index=o.series.indexOf(s);
   o.labels.forEach((_,i)=>{const v=s.values[i];if(!hasValue(v))return;const bx=x(i)-group/2+index*bw,by=y(v);svg+=`<rect x="${bx+2}" y="${by}" width="${Math.max(2,bw-4)}" height="${Math.max(0,bottom-by)}" rx="3" fill="${esc(s.pointColors?.[i]??s.color)}"/>`;if(v===0)svg+=`<line x1="${bx+2}" x2="${bx+bw-2}" y1="${bottom}" y2="${bottom}" stroke="${esc(s.pointColors?.[i]??s.color)}" stroke-width="3"/>`;});
  }
 });
 if(!values.length)svg+=text(width/2,(top+bottom)/2,'Chưa có dữ liệu trong khoảng ngày này',21,'#94a08c','text-anchor="middle"');
 legendItems.forEach(({x,row,series:s})=>{svg+=`<line x1="${x}" x2="${x+25}" y1="${bottom+80+row*34}" y2="${bottom+80+row*34}" stroke="${esc(s.color)}" stroke-width="5"/>`;svg+=text(x+36,bottom+86+row*34,s.name,17,'#596f52')});
 svg+=text(64,height-29,o.note||'Ngày chưa có bản ghi được để trống, không tính là 0.',15,'#8b9782');return svg+'</g></svg>';
}
export async function createChartPng(options:ChartImageOptions,filename:string){
 const svg=buildChartSvg(options),url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
 try{
  const img=new Image();await new Promise<void>((resolve,reject)=>{img.onload=()=>resolve();img.onerror=()=>reject(new Error('Không thể tạo ảnh biểu đồ.'));img.src=url});
  const canvas=document.createElement('canvas');canvas.width=img.naturalWidth*2;canvas.height=img.naturalHeight*2;const ctx=canvas.getContext('2d');if(!ctx)throw Error('Trình duyệt chưa hỗ trợ xuất ảnh.');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
  const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Không tạo được ảnh PNG.')),'image/png'));
  return {blob,url:URL.createObjectURL(blob),filename:filename.endsWith('.png')?filename:filename+'.png'};
 }finally{URL.revokeObjectURL(url)}
}
