export function csvCell(value:unknown){
 if(typeof value==='number')return String(value);
 let text=String(value??'');
 if(/^[\s]*[=+@-]/.test(text))text="'"+text;
 return '"'+text.replaceAll('"','""')+'"';
}
export const csvRow=(values:unknown[])=>values.map(csvCell).join(',');
