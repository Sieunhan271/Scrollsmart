import {shift} from './stats';
export type DailyAggregate={date:string;participants:number;totalNegative:number;above:number;equal:number;below:number};
export function communityWeek(start:string,rows:DailyAggregate[]){return Array.from({length:7},(_,i)=>{const date=shift(start,i),r=rows.find(r=>r.date===date);return {date,participants:r?.participants??0,averageNegative:r&&r.participants?Math.round(r.totalNegative/r.participants*100)/100:null,above:r?r.above:null,equal:r?r.equal:null,below:r?r.below:null}})}
