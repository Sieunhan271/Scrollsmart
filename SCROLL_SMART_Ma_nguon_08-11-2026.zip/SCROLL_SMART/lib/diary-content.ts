export const LAST_FIVE_MINUTES_MAX=2000;
export function parseLastFiveMinutes(value:unknown):string|null|undefined{
 if(value===undefined)return undefined;
 if(value===null)return null;
 if(typeof value!=='string')throw new Error('Nội dung 5 phút cuối phải là văn bản.');
 const content=value.trim();
 if(content.length>LAST_FIVE_MINUTES_MAX)throw new Error('Nội dung 5 phút cuối tối đa 2.000 kí tự.');
 return content||null;
}
