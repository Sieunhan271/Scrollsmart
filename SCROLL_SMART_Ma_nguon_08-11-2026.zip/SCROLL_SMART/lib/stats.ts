export type Entry={date:string;planned:number;actual:number;negative:number;lastFiveMinutes?:string|null};
export const shift=(d:string,n:number)=>{const x=new Date(d+'T12:00:00Z');x.setUTCDate(x.getUTCDate()+n);return x.toISOString().slice(0,10)};
export const monday=(d:string)=>shift(d,-((new Date(d+'T12:00:00Z').getUTCDay()+6)%7));
export function summarize(rows:Entry[]){const sum=(k:'actual'|'planned'|'negative')=>rows.reduce((s,r)=>s+r[k],0);return {count:rows.length,total:sum('actual'),planned:sum('planned'),negative:sum('negative'),average:rows.length?Math.round(sum('actual')/rows.length):null,within:rows.filter(r=>r.actual<=r.planned).length}}
