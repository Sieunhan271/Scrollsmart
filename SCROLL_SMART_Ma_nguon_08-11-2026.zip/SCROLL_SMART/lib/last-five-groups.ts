import {shift} from './stats';
export const contentGroups=[
 {id:'news',label:'Tin tức, xã hội & môi trường',shortLabel:'Tin tức',color:'#b76b55'},
 {id:'entertainment',label:'Giải trí, âm nhạc & phim',shortLabel:'Giải trí',color:'#7b78b5'},
 {id:'study',label:'Học tập & trường lớp',shortLabel:'Học tập',color:'#56969a'},
 {id:'sports_games',label:'Thể thao & trò chơi',shortLabel:'Thể thao/game',color:'#c29843'},
 {id:'lifestyle',label:'Đời sống, sở thích & tiêu dùng',shortLabel:'Đời sống',color:'#5d956d'},
 {id:'social',label:'Bạn bè, giao tiếp & bình luận',shortLabel:'Giao tiếp',color:'#618eb8'},
 {id:'unclear',label:'Khác / chưa đủ thông tin',shortLabel:'Chưa rõ',color:'#929292'},
 {id:'not_used',label:'Không sử dụng mạng xã hội',shortLabel:'Không sử dụng',color:'#a68d75'},
] as const;
export type ContentGroup=typeof contentGroups[number]['id'];
export function normalizeContent(text:string){return text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replaceAll('đ','d').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim()}
export function classifyLastFive(text:string|null|undefined):ContentGroup[]{
 if(!text?.trim())return [];
 const s=normalizeContent(text),groups:ContentGroup[]=[];
 const patterns:[ContentGroup,RegExp][]=[
 ['news',/\b(tin tuc|thoi su|tin xau|tai nan|lua dao|xung dot|chien tranh|chay no|mua bao|ngap lut|bao luc|o nhiem|moi truong|thien tai|dich benh|chinh tri|kinh te|phap luat)\b/],
 ['entertainment',/\b(giai tri|hai|meme|nhac|ca si|phim|hoat hinh|showbiz|trend|ke chuyen vui|nhay)\b/],
 ['study',/\b(hoc tap|on tap|bai giang|bai tap|sinh hoc|toan hoc|tieng anh|kien thuc|hoat dong cua truong|hoat dong truong|hoc ngoai ngu|hoc bai|hoc truc tuyen)\b/],
 ['sports_games',/\b(the thao|game|gaming|bong da|bong chuyen|bong ro|cau long|ban thang|the duc|tap gym|chay bo|boi loi|tennis|pickleball)\b/],
 ['lifestyle',/\b(cuoc song hang ngay|thu cung|meo|cun|dong vat|nau an|lam banh|do an|an uong|di an|quan an|review|dap hop|do dung|trang diem|phoi do|du lich|phong canh|ve tranh|huong dan ve|thu cong|lam dep|ban do|ban hang)\b/],
 ['social',/\b(binh luan|nhan tin|tro chuyen|chat|story|trang ca nhan|nhom lop|bai dang cua ban be|bai ban be|ban be dang anh|anh ban be)\b/],
 ];
 for(const [id,pattern] of patterns)if(pattern.test(s))groups.push(id);
 // A review of a film/game is content in that domain, not a shopping review.
 if(groups.includes('lifestyle')&&/\breview (phim|game)\b/.test(s)&&! /\b(do an|dien thoai|quan an|du lich|my pham)\b/.test(s))groups.splice(groups.indexOf('lifestyle'),1);
 if(groups.length)return groups;
 if(/\b(khong|ko) (su dung|dung|luot|vao) (mang xa hoi|mxh|facebook|tiktok)\b/.test(s)||/^(khong su dung|khong dung|khong xem|khong luot|khong co|khong|ko)$/.test(s))return ['not_used'];
 return ['unclear'];
}
export type ContentAnswer={date:string;lastFiveMinutes:string|null};
export function summarizeLastFive(start:string,rows:ContentAnswer[]){
 return Array.from({length:7},(_,i)=>{
  const date=shift(start,i),daily=rows.filter(r=>r.date===date),answers=daily.map(r=>classifyLastFive(r.lastFiveMinutes)).filter(ids=>ids.length>0),counts=Object.fromEntries(contentGroups.map(g=>[g.id,0])) as Record<ContentGroup,number>;
  answers.forEach(ids=>new Set(ids).forEach(id=>counts[id]++));
  const averages=Object.fromEntries(contentGroups.map(g=>[g.id,answers.length?counts[g.id]/answers.length:null])) as Record<ContentGroup,number|null>;
  return {date,diaries:daily.length,answered:answers.length,unanswered:daily.length-answers.length,counts,averages};
 });
}
