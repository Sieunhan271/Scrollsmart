import { isAdmin } from './admin-auth';
import Diary from './diary';
import { getChatGPTUser } from './chatgpt-auth';
export const dynamic='force-dynamic';
export default async function Home(){const user=await getChatGPTUser();return <><Diary signedIn={!!user}/>{await isAdmin()&&<a className="admin-float primary" href="/admin">Quản trị toàn hệ thống →</a>}</>;}
