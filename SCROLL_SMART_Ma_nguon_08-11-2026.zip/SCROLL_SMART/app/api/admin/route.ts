import {parseLastFiveMinutes} from '../../../lib/diary-content';
import { roster } from '../../../lib/roster';
import { env } from 'cloudflare:workers';
import { isAdmin } from '../../admin-auth';
import { getDb } from '../../../db';
import { profiles,entries } from '../../../db/schema';
import { eq,and } from 'drizzle-orm';
export const dynamic='force-dynamic';
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){if(!await isAdmin())return reply({error:'Bạn không có quyền quản trị.'},403);const db=getDb();return reply({profiles:await db.select().from(profiles).all(),entries:await db.select().from(entries).all()});}
export async function POST(req:Request){
 const key=(env as unknown as Record<string,string>).ADMIN_MAINTENANCE_KEY;
 const maintenance=!!key&&req.headers.get('authorization')==='Bearer '+key;
 if(!maintenance){if(req.headers.get('origin')!==new URL(req.url).origin)return reply({error:'Yêu cầu không hợp lệ.'},403);if(!await isAdmin())return reply({error:'Bạn không có quyền quản trị.'},403);}
 let b:any;try{b=await req.json()}catch{return reply({error:'Dữ liệu không hợp lệ.'},400)}
 if(maintenance&&b.action!=='importRoster')return reply({error:'Thao tác không được cấp quyền.'},403);
 const db=getDb();if(maintenance&&b.action==='importRoster'){const make=(code:string)=>db.insert(profiles).values({code,userId:crypto.randomUUID()}).onConflictDoNothing();await db.batch([make(roster[0]),...roster.slice(1).map(make)]);return reply({ok:true,count:roster.length});}
 const p=await db.select().from(profiles).where(eq(profiles.code,String(b.code))).get();if(!p)return reply({ok:true,deleted:false});
 if(b.action==='deleteProfile'){await db.batch([db.delete(entries).where(eq(entries.userId,p.userId)),db.delete(profiles).where(eq(profiles.userId,p.userId))]);return reply({ok:true,deleted:true});}
 if(b.action==='rename'){const code=String(b.newCode||'').trim().toUpperCase();if(!/^[A-Z0-9_-]{2,24}$/.test(code))return reply({error:'Mã không hợp lệ.'},400);try{await db.update(profiles).set({code}).where(eq(profiles.userId,p.userId)).run()}catch{return reply({error:'Mã mới đã được sử dụng.'},409)}return reply({ok:true});}
 const date=String(b.date||'');if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||isNaN(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date)return reply({error:'Ngày không hợp lệ.'},400);
 if(b.action==='deleteEntry'){await db.delete(entries).where(and(eq(entries.userId,p.userId),eq(entries.date,date))).run();return reply({ok:true});}
 if(b.action==='saveEntry'){
 const {planned,actual,negative}=b;
 let content:string|null|undefined;try{content=parseLastFiveMinutes(b.lastFiveMinutes)}catch(e){return reply({error:(e as Error).message},400)}const today=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'});
 if(date>today||![planned,actual,negative].every(Number.isInteger)||planned<0||planned>1440||actual<0||actual>1440||negative<0||negative>100000)return reply({error:'Kiểm tra ngày và số liệu: thời gian 0–1440 phút, số tin không âm.'},400);
 await db.insert(entries).values({userId:p.userId,date,planned,actual,negative,lastFiveMinutes:content??null,updatedAt:new Date().toISOString()}).onConflictDoUpdate({target:[entries.userId,entries.date],set:{planned,actual,negative,...(content!==undefined?{lastFiveMinutes:content}:{}),updatedAt:new Date().toISOString()}}).run();return reply({ok:true});}
 return reply({error:'Thao tác không hợp lệ.'},400);
}
