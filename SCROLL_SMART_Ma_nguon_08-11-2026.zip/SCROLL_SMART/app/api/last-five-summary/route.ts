import {getDb} from '../../../db';
import {entries,profiles} from '../../../db/schema';
import {and,eq,gte,lte} from 'drizzle-orm';
import {monday,shift} from '../../../lib/stats';
import {summarizeLastFive} from '../../../lib/last-five-groups';
export const dynamic='force-dynamic';
export async function GET(req:Request){
 const input=new URL(req.url).searchParams.get('week')||new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'});
 if(!/^\d{4}-\d{2}-\d{2}$/.test(input)||isNaN(Date.parse(input))||new Date(input).toISOString().slice(0,10)!==input)return Response.json({error:'Ngày không hợp lệ.'},{status:400});
 const week=monday(input),rows=await getDb().select({date:entries.date,lastFiveMinutes:entries.lastFiveMinutes}).from(entries).innerJoin(profiles,eq(entries.userId,profiles.userId)).where(and(gte(entries.date,week),lte(entries.date,shift(week,6)))).all();
 return Response.json({week,days:summarizeLastFive(week,rows)},{headers:{'Cache-Control':'no-store'}});
}
