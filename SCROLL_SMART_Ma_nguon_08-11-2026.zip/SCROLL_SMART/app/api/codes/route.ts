import {getDb} from '../../../db';
import {profiles} from '../../../db/schema';
import {asc} from 'drizzle-orm';
export const dynamic='force-dynamic';
export async function GET(){return Response.json({codes:(await getDb().select({code:profiles.code}).from(profiles).orderBy(asc(profiles.code)).all()).map(p=>p.code)},{headers:{'Cache-Control':'no-store'}})}
