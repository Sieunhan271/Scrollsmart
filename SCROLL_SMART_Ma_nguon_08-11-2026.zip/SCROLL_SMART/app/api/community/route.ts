import {getDb} from '../../../db';
import {entries,profiles} from '../../../db/schema';
import {eq,and,gte,lte,sql,count,max} from 'drizzle-orm';
import {monday,shift} from '../../../lib/stats';
import {communityWeek} from '../../../lib/community';
export const dynamic='force-dynamic';
export async function GET(req:Request){
 const input=new URL(req.url).searchParams.get('week')||new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'});
 if(!/^\d{4}-\d{2}-\d{2}$/.test(input)||isNaN(Date.parse(input))||new Date(input).toISOString().slice(0,10)!==input)return Response.json({error:'Ngày không hợp lệ.'},{status:400});
 const start=monday(input),db=getDb();
 const aggregates=await db.select({date:entries.date,participants:count(),totalNegative:sql<number>`coalesce(sum(${entries.negative}),0)`,above:sql<number>`sum(case when ${entries.actual} > ${entries.planned} then 1 else 0 end)`,equal:sql<number>`sum(case when ${entries.actual} = ${entries.planned} then 1 else 0 end)`,below:sql<number>`sum(case when ${entries.actual} < ${entries.planned} then 1 else 0 end)`}).from(entries).innerJoin(profiles,eq(entries.userId,profiles.userId)).where(and(gte(entries.date,start),lte(entries.date,shift(start,6)))).groupBy(entries.date).all();
 const [total,latest]=await Promise.all([db.select({count:count()}).from(profiles).get(),db.select({date:max(entries.date)}).from(entries).innerJoin(profiles,eq(entries.userId,profiles.userId)).get()]);
 return Response.json({week:start,totalParticipants:total?.count??0,latestDate:latest?.date??null,days:communityWeek(start,aggregates)},{headers:{'Cache-Control':'no-store'}});
}
