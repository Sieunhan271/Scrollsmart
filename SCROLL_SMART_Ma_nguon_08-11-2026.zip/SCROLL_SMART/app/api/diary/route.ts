import {parseLastFiveMinutes} from '../../../lib/diary-content';
import { getParticipant } from '../../participant-auth';
import { getDb } from '../../../db';
import { profiles, entries } from '../../../db/schema';
import { eq, and } from 'drizzle-orm';
export const dynamic='force-dynamic';
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){
 const profile=await getParticipant(); const db=getDb();
 const rows=profile?await db.select({date:entries.date,planned:entries.planned,actual:entries.actual,negative:entries.negative,lastFiveMinutes:entries.lastFiveMinutes}).from(entries).where(eq(entries.userId,profile.userId)).all():[];
 return reply({code:profile?.code??null,entries:rows});
}
export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return reply({error:'Yêu cầu không hợp lệ.'},403);
 const profile=await getParticipant();if(!profile)return reply({error:'Vui lòng chọn mã để đăng nhập lại.'},401);
 let b:any;try{b=await req.json()}catch{return reply({error:'Dữ liệu không hợp lệ.'},400)}
 const db=getDb();
 const {date,planned,actual,negative}=b;
 let content:string|null|undefined;try{content=parseLastFiveMinutes(b.lastFiveMinutes)}catch(e){return reply({error:(e as Error).message},400)}
 const today=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'});
 if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date)||isNaN(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>today)return reply({error:'Chọn ngày hợp lệ, không sau hôm nay.'},400);
 if(![planned,actual,negative].every(Number.isInteger)||planned<0||actual<0||planned>1440||actual>1440||negative<0||negative>100000)return reply({error:'Thời gian từ 0–1440 phút; số tin phải là số nguyên không âm.'},400);
 await db.insert(entries).values({userId:profile.userId,date,planned,actual,negative,lastFiveMinutes:content??null,updatedAt:new Date().toISOString()}).onConflictDoUpdate({target:[entries.userId,entries.date],set:{planned,actual,negative,...(content!==undefined?{lastFiveMinutes:content}:{}),updatedAt:new Date().toISOString()}}).run();
 return reply({ok:true});
}
