import {cookies} from 'next/headers';
import {getDb} from '../../../db';
import {profiles} from '../../../db/schema';
import {eq} from 'drizzle-orm';
import {cookieName,cookieOptions,signSession} from '../../participant-auth';
export const dynamic='force-dynamic';
export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Yêu cầu không hợp lệ.'},{status:403});
 let b:any;try{b=await req.json()}catch{return Response.json({error:'Chọn mã nghiên cứu.'},{status:400})}
 const profile=await getDb().select().from(profiles).where(eq(profiles.code,String(b.code))).get();if(!profile)return Response.json({error:'Mã này không có trong danh sách.'},{status:400});
 (await cookies()).set(cookieName,await signSession(profile.userId),cookieOptions);return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});
}
export async function DELETE(req:Request){if(req.headers.get('origin')!==new URL(req.url).origin)return new Response(null,{status:403});(await cookies()).set(cookieName,'',{...cookieOptions,maxAge:0});return Response.json({ok:true});}
