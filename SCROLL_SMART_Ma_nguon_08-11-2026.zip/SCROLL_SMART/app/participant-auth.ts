import {cookies} from 'next/headers';
import {env} from 'cloudflare:workers';
import {getDb} from '../db';
import {profiles} from '../db/schema';
import {eq} from 'drizzle-orm';
const encoder=new TextEncoder();
export const cookieName='scroll_participant';
export const cookieOptions={httpOnly:true,secure:true,sameSite:'none' as const,path:'/',partitioned:true,maxAge:60*60*24*30};
async function key(){const secret=(env as unknown as Record<string,string>).PARTICIPANT_SESSION_SECRET;if(!secret)throw Error('Session configuration unavailable');return crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
const hex=(bytes:ArrayBuffer)=>Array.from(new Uint8Array(bytes)).map(x=>x.toString(16).padStart(2,'0')).join('');
export async function signSession(userId:string){const payload=btoa(JSON.stringify({userId,expires:Date.now()+cookieOptions.maxAge*1000}));return payload+'.'+hex(await crypto.subtle.sign('HMAC',await key(),encoder.encode(payload)));}
export async function getParticipant(){
 const token=(await cookies()).get(cookieName)?.value;if(!token)return null;
 try{const [payload,signature,...extra]=token.split('.');if(extra.length||!payload||!signature||!/^[0-9a-f]{64}$/.test(signature))return null;
 const valid=await crypto.subtle.verify('HMAC',await key(),Uint8Array.from(signature.match(/../g)!,x=>parseInt(x,16)),encoder.encode(payload));if(!valid)return null;
 const data=JSON.parse(atob(payload));if(typeof data.userId!=='string'||typeof data.expires!=='number'||data.expires<Date.now())return null;
 return await getDb().select().from(profiles).where(eq(profiles.userId,data.userId)).get()??null;
 }catch{return null}
}
