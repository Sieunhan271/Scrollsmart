import { isAdmin } from '../admin-auth';
import Admin from './panel';
export const dynamic='force-dynamic';
export default async function Page(){if(!await isAdmin())return <main className="welcome"><h1>Khu vực quản trị</h1><p>Đăng nhập bằng tài khoản quản trị được cấp quyền.</p><a className="primary" href="/signin-with-chatgpt?return_to=%2Fadmin" target="_top">Đăng nhập quản trị</a></main>;return <Admin/>;}
