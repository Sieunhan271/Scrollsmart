'use client';
import {useEffect,useRef,useState} from 'react';
import {Download,ExternalLink,Share2,X} from 'lucide-react';
import {createChartPng,type ChartImageOptions} from '../../lib/chart-image';
type PngAsset=Awaited<ReturnType<typeof createChartPng>>;
export default function ChartDownload({getOptions,filename,disabled=false}:{getOptions:()=>ChartImageOptions;filename:string;disabled?:boolean}){
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[asset,setAsset]=useState<PngAsset|null>(null),[shareError,setShareError]=useState(''),[canShare,setCanShare]=useState(false),[downloadRequested,setDownloadRequested]=useState(false);
 const dialog=useRef<HTMLDialogElement>(null);
 useEffect(()=>{if(!asset)return;setShareError('');setDownloadRequested(false);const file=new File([asset.blob],asset.filename,{type:'image/png'});try{setCanShare(!!navigator.canShare?.({files:[file]}))}catch{setCanShare(false)}
  if(dialog.current){if(typeof dialog.current.showModal==='function')dialog.current.showModal();else dialog.current.setAttribute('open','')}
  return()=>{setTimeout(()=>URL.revokeObjectURL(asset.url),60000)};
 },[asset]);
 async function prepare(){setBusy(true);setError('');try{setAsset(await createChartPng(getOptions(),filename))}catch(e){setError((e as Error).message||'Chưa tạo được ảnh, vui lòng thử lại.')}finally{setBusy(false)}}
 function close(){dialog.current?.close();setAsset(null)}
 async function share(){if(!asset)return;setShareError('');try{await navigator.share({files:[new File([asset.blob],asset.filename,{type:'image/png'})]})}catch(e){if((e as Error).name!=='AbortError')setShareError('Trình duyệt này chưa cho phép chia sẻ ảnh. Bạn có thể nhấn giữ ảnh bên dưới rồi chọn lưu ảnh.')}}
 return <div className="chart-download"><button className="secondary" type="button" onClick={prepare} disabled={disabled||busy} aria-label="Tải ảnh PNG của biểu đồ này"><Download size={15}/><span>{busy?'Đang tạo ảnh…':'Tải ảnh PNG'}</span></button>{error&&<span className="chart-download-error" role="alert">{error}</span>}
 <dialog className="png-dialog" ref={dialog} onClose={()=>setAsset(null)} onClick={e=>{if(e.target===e.currentTarget)close()}} aria-labelledby="png-dialog-title">
 {asset&&<div className="png-dialog-inner"><div className="png-dialog-heading"><div><h2 id="png-dialog-title">Ảnh biểu đồ đã sẵn sàng</h2><p>Chọn cách lưu ảnh về thiết bị của bạn.</p></div><button type="button" className="png-dialog-close" onClick={close} aria-label="Đóng ảnh biểu đồ"><X size={20}/></button></div>
 <div className="png-dialog-actions"><a className="primary" href={asset.url} download={asset.filename} target="_blank" rel="noopener noreferrer" onClick={()=>setDownloadRequested(true)}><Download size={17}/> Tải về thiết bị</a>{canShare&&<button type="button" className="secondary" onClick={share}><Share2 size={17}/> Lưu / chia sẻ</button>}<a className="secondary" href={asset.url} target="_blank" rel="noopener noreferrer"><ExternalLink size={17}/> Mở ảnh riêng</a></div>
 <p className="png-save-help">Trên điện thoại: nhấn giữ ảnh bên dưới, rồi chọn “Lưu hình ảnh” hoặc “Tải hình ảnh xuống”. Trên máy tính: bấm “Tải về thiết bị”.</p>
 {downloadRequested&&<p className="png-save-status" role="status">Đã gửi yêu cầu tải xuống. Nếu chưa thấy tệp trong mục Tải xuống, hãy nhấn giữ ảnh để lưu hoặc chọn “Mở ảnh riêng”.</p>}{shareError&&<p role="alert" className="error">{shareError}</p>}
 <div className="png-preview"><img src={asset.url} alt="Ảnh PNG của biểu đồ đang xem; nhấn giữ để lưu ảnh trên điện thoại"/></div><p className="png-filename">{asset.filename}</p>
 </div>}
 </dialog></div>
}
