import { env } from 'cloudflare:workers';
import { getChatGPTUser } from './chatgpt-auth';
export async function isAdmin(){const user=await getChatGPTUser();const email=(env as unknown as Record<string,string>).ADMIN_EMAIL;return !!(email&&user&&user.email.toLowerCase()===email.toLowerCase());}
