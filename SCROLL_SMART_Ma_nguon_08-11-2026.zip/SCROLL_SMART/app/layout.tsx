import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'SCROLL SMART — Nhật kí của bạn',description:'Hiểu thói quen của mình. Lướt mạng có chủ đích, mỗi ngày một chút.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="vi"><body>{children}</body></html>}
