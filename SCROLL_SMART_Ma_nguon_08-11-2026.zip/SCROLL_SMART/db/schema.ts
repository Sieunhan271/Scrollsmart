import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';
export const profiles = sqliteTable('profiles', {userId:text('user_id').primaryKey(),code:text('code').notNull().unique()});
export const entries = sqliteTable('entries', {userId:text('user_id').notNull(),date:text('date').notNull(),planned:integer('planned').notNull(),actual:integer('actual').notNull(),negative:integer('negative').notNull(),lastFiveMinutes:text('last_five_minutes'),updatedAt:text('updated_at').notNull()},t=>[primaryKey({columns:[t.userId,t.date]})]);
