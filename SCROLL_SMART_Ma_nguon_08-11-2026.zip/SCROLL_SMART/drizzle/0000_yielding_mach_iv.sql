CREATE TABLE `entries` (
	`user_id` text NOT NULL,
	`date` text NOT NULL,
	`planned` integer NOT NULL,
	`actual` integer NOT NULL,
	`negative` integer NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `date`)
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `profiles_code_unique` ON `profiles` (`code`);